USE CARRITO;

INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Manzanas', 1.99);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Naranjas', 2.49);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Plátanos', 0.79);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Fresas', 3.50);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Uvas', 2.99);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Tomates', 1.29);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Zanahorias', 0.99);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Lechuga', 1.39);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Espinacas', 1.89);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Pimientos', 2.29);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Patatas', 0.89);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Cebollas', 0.79);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Ajos', 2.99);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Calabacines', 1.49);
INSERT INTO PRODUCTS (nomprod, precio) VALUES ('Berenjenas', 1.69);
